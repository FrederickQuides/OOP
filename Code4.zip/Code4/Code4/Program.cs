﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num1;
            double num2;
            double max;
            Console.Write("Enter the first number: ");
            num1 = double.Parse(Console.ReadLine());

            Console.Write("Enter the second number: ");
            num2 = double.Parse(Console.ReadLine());

            max = Math.Max(num1, num2);
            Console.WriteLine($"The maximum number is {max}");
        }
    }
}
