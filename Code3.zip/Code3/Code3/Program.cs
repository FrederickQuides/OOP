﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string oras;
            string mTime;
            Console.Write("Enter the time in 12 hour format: ");
            oras = Console.ReadLine();

            mTime = TimeConversion(oras);

            Console.WriteLine("The time in 24 hour format is: " + mTime);
        }
        static string TimeConversion(string time)
        {
            DateTime dateTime = DateTime.ParseExact(time, "hh:mm:sstt",
                System.Globalization.CultureInfo.InvariantCulture);


            return dateTime.ToString("HH:mm:ss");

        }
    }
}
