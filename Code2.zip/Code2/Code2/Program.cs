﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            long[] numbers = Array.ConvertAll(Console.ReadLine().Split(''), long.Parse);

            miniMaxSum(numbers);
        }
        static void miniMaxSum(long[] arr)
        {
            Array.Sort(arr);

            long minSum = arr.Take(4).Sum();

            long maxSum = arr.Skip(4).Sum();

            Console.WriteLine($"{minSum} {maxSum}");
        }
    }
}
