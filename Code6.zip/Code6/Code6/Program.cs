﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int speedlimit;
            int carspeed;
            int demeritpoints;

            //The user will enter the speed limit
            Console.Write("Enter the speed limit: ");
            speedlimit = int.Parse(Console.ReadLine());

            //The user will enter the speed of the car
            Console.Write("Enter the speed of the car: ");
            carspeed = int.Parse(Console.ReadLine());

            demeritpoints = (carspeed - speedlimit) / 5;
            Console.WriteLine($"Demerit Points: {demeritpoints}");
            //the code will tell if the carspeed is less than or equal to speedlimit
            if (carspeed <= speedlimit)
            {
                Console.WriteLine("Ok");
            }

            // The demeritpoints will be calculated if the carspeed is greater than speedlimit
            else if (demeritpoints > 12)
            {
                Console.WriteLine("Licence Suspended");
            }
            else
            {
                Console.WriteLine();
            }
        }
    }
}