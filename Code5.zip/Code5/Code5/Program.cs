﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;

            // User input : The user will be ask to enter a number between 1-10
            Console.Write("Enter a number from 1 - 10: ");
            num = int.Parse(Console.ReadLine());

            //If else statement : If the user enters a number between 1 - 10 the program execute it "valid".
            // If the user enters not number from 1 - 10 the program would say "invalid"
            if (num >= 1 && num <= 10)
            {
                Console.WriteLine("Valid");
            }
            else
            {
                Console.WriteLine("Invalid");
            }
        }
    }
}
